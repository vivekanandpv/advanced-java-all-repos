package com.company;

public class Main {

    public static void main(String[] args) {
	    //  Functional Paradigm
        //  This is a mathematical programming model
        //  Salient features:
        //      No shared variables
        //      Recursion instead of loops
        //      Pure functions
        //  These features make parallel programming much easier
        //  But Java is not optimized for recursion
        //  Recursive algorithms add a lot of overhead for large datasets
        //  Java 8 introduced Stream API which tends to strike the optimum
        //  balance. This should not be confused with streams of disk or network I/O.

        //  Along with Stream API, Java 8 also introduced other constructs
        //  that enabled functional programming (as much as possible).

        //  We study the Stream API in 5 incremental steps:
        //      1. Additions to interfaces
        //      2. Functional interfaces
        //      3. Lambda expressions
        //      4. Stream API core concepts
        //      5. Operators and important use cases
    }
}
