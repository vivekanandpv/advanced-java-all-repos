package com.example.springdockerizing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDockerizingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDockerizingApplication.class, args);
    }

}
